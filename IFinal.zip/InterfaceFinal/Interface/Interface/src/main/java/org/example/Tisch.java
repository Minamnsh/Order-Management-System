package org.example;

import java.time.LocalDate;

public class Tisch extends Sache {


    int tischBeine;


    /**
     * @param beine       Anzahl der Tischbeine
     * @param tischId     Eindeutige Id des Tisches
     * @param tischName   Bezeichnung
     * @param bauDatum    Datum der Erstellung
     * @param tischPlatte Material der Tischplatte
     */
    public Tisch(String tischId, int beine, String tischName, LocalDate bauDatum, String tischPlatte,
                 float gewicht, float laenge, float bereite,
                 float hoehe, float zerbrechlich, int barcode) {
        this.setSachId(tischId);
        this.setName(tischName);
        this.setHerstellDatum(bauDatum);
        this.setType(tischPlatte);
        this.tischBeine = beine;
        this.setGewicht(gewicht);
        this.setLaenge(laenge);
        this.setBereite(bereite);
        this.setHoehe(hoehe);
        this.zerbrechlich(zerbrechlich);
        this.barcode(barcode);
    }


}