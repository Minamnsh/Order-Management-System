package org.example;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Sache implements ITransportSchnittStelle {

    String id;
    String name;
    LocalDate herstellDatum;
    String type;

    float hoehe;
    float bereite;
    float laenge;
    float gewicht;
    float volomen;
    private String fileSpeicherSache = "D:\\Job\\Wiberry\\Java\\InterfaceFinal\\Interface\\Interface\\target\\speicherSache.txt";

    public String getName() {
        return name;
    }

    public LocalDate getHerstellDatum() {
        return herstellDatum;
    }

    public String getType() {
        return type;
    }

    public float getHoehe() {
        return hoehe;
    }

    public float getBereite() {
        return bereite;
    }

    public float getLaenge() {
        return laenge;
    }


    public String getSachId() {
        return id;
    }

    /*public LocalDate getTransportDate() {
        return transportDate;
    }*/

    public void setGewicht(float gewicht) {
        this.gewicht = gewicht;
    }

    public void setHoehe(float hoehe) {
        this.hoehe = hoehe;
    }

    public void setBereite(float bereite) {
        this.bereite = bereite;
    }

    public void setLaenge(float laenge) {
        this.laenge = laenge;
    }

    public float getVolumen() {
        float vol = bereite * hoehe * laenge;
        return vol;
    }


    public void setType(String type) {
        this.type = type;
    }

    public void setSachId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHerstellDatum(LocalDate datum) {
        this.herstellDatum = datum;
    }

    public float getGewicht() {
        return gewicht;
    }

    public float zerbrechlich(float zerbrechlich) {
        return zerbrechlich;
    }

    public int barcode(int barcode) {
        return barcode;
    }

    public void setVolumnen() {
        this.volomen = getVolumen();
    }

    public void sachSpeicher() {
        try {
            Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileSpeicherSache, true), "UTF-8"));
            PrintWriter out = new PrintWriter(writer);
            out.println(getSachId() + ";" + getName() + ";" + getHerstellDatum() + ";" + getType());
            out.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
