package org.example;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

class Bestellung extends Kunde {
    LocalDate transportDate;
    private String bId;
    private String fileSpeicherBestellung = "D:\\Job\\Wiberry\\Java\\InterfaceFinal\\Interface\\Interface\\target\\speicherBestellung.txt";

    public String getbId() {
        return bId;
    }

    public void setbId(String bId) {
        this.bId = bId;
    }


    private LocalDate bestelldatum;
    //C:\Users\Mina Maneshi\IdeaProjects\InterfaceFinal\Interface\Interface\target\speicher.txt
    private List<ITransportSchnittStelle> transportElemente;

    public void setTransportDate(LocalDate tdate) {
        this.transportDate = tdate;
    }
    public LocalDate getBestelldatum() {
        return bestelldatum;
    }

    public void setBestelldatum(LocalDate bestelldatum) {
        this.bestelldatum = bestelldatum;
    }

    public List<ITransportSchnittStelle> getTransportElemente() {
        return transportElemente;
    }

    public void setTransportElemente(List<ITransportSchnittStelle> transportElemente) {
        this.transportElemente = transportElemente;
    }
    public Bestellung(String bestellungId,String kundeId, String sachId, LocalDate bestelldatum, LocalDate auslieferungsdatum) {
        this.bId = bestellungId;
        this.bestelldatum = bestelldatum;
        this.setkId(kundeId);
        this.setTransportDate(auslieferungsdatum);
        this.setSachId(sachId);
    }




    public void bestellungAufgeben(List<ITransportSchnittStelle> inElemente) {
        transportElemente = new ArrayList<ITransportSchnittStelle>();
        for (ITransportSchnittStelle element : inElemente) {
            transportElemente.add(element);
        }
       // System.out.println("Bestellung aufgegeben für " + vorname + " " + nachname);

    }


    public float volumenBerechnen() {
        float volumen = 0;
        for (ITransportSchnittStelle element : transportElemente) {
            volumen += element.getVolumen();
        }
        return volumen;
    }

    public float gewichtBerechnen() {
        float gewicht = 0;
        for (ITransportSchnittStelle element : transportElemente) {
            gewicht += element.getGewicht();
        }
        return gewicht;
    }
    public void bestellungSpeicher() {
        try {
            Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileSpeicherBestellung, true), "UTF-8"));
            PrintWriter out = new PrintWriter(writer);
            out.println(  getbId() + ";" + getBestelldatum() + ";"+getkundeId()+";"+ getNachname() + ";" + getSachId());
            out.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}





