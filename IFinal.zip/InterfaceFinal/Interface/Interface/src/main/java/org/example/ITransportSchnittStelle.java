package org.example;

public interface ITransportSchnittStelle {
    public float zerbrechlich(float zerbrechlich);
    public void setHoehe(float hoehe);
    public void setBereite(float bereite);
    public void setLaenge(float laenge);

    float getVolumen();

    float getGewicht();
}
