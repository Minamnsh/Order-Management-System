package org.example;

import java.time.LocalDate;

public class Fahrrad extends Sache {


    String fahrradHersteller;

    String fahrradFarbe;

    public Fahrrad(String fahrradId, String fahrradName, String fahrradType, String hersteller,
                   String farbe, LocalDate baujahr, float gewicht, float laenge, float bereite,
                   float hoehe, float zerbrechlich, int barcode) {
        this.setSachId(fahrradId);
        this.setName(fahrradName);
        this.setHerstellDatum(baujahr);
        this.setType(fahrradType);
        this.fahrradHersteller = hersteller;
        this.fahrradFarbe = farbe;
        this.setGewicht(gewicht);
        this.setLaenge(laenge);
        this.setBereite(bereite);
        this.setHoehe(hoehe);
        this.zerbrechlich(zerbrechlich);
        this.barcode(barcode);
        this.setVolumnen();
    }


}
