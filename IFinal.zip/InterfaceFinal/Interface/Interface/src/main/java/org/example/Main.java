package org.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now().plusDays(5);
        Bestellung bestellung = new Bestellung("b1001", "k2001","S5001",LocalDate.now(), date);
        List<ITransportSchnittStelle> sache = new ArrayList<ITransportSchnittStelle>();
        sache.add(new Tisch("T1005", 4, "Tisch1", LocalDate.now(), "Eiche",  2, 2, 2, 2, 2, 101));
        sache.add(new Fahrrad("F1001", "Fahrrad1", "type", "Hersteller", "Farbe", LocalDate.now(),  3, 3, 3, 3, 3, 102));
        sache.add(new Schaf("S1002", "Schaf", "Rasse", LocalDate.now().minusDays(3),  4, 4, 4, 4, 4, 103));

        bestellung.bestellungAufgeben(sache);
        BestellungSpeichernDatei bestellungSpeichern = new BestellungSpeichernDatei();
        bestellungSpeichern.bestellungSpeichern(bestellung);
        List<Bestellung> geladeneBestellungen = bestellungSpeichern.ladeBestellungen();
        System.out.println("Gespeicherte Bestellungen:");
        for (Bestellung bestellungen : geladeneBestellungen) {
          //  System.out.println(bestellung.getVorname() + " " + bestellung.getNachname());
        }
        Kunde kunde= new Kunde();
        kunde.kundeInfo("k101","Mina","Maneshi","Calenberger Str.","46",30169,"Deutschland","+4915906311766");

        System.out.println("Volumen der Bestellung: " + bestellung.volumenBerechnen());
        System.out.println("Gewicht der Bestellung: " + bestellung.gewichtBerechnen());
        bestellung.bestellungSpeicher();

        try {
            kunde.kundeSpeicher();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
        Tisch tisch= new Tisch("T1005", 4, "Tisch1", LocalDate.now(), "Eiche",  2, 2, 2, 2, 2, 101);
        tisch.sachSpeicher();
        Fahrrad fahrrad= new Fahrrad("F1001", "Fahrrad1", "type", "Hersteller", "Farbe", LocalDate.now(),  3, 3, 3, 3, 3, 102);
        fahrrad.sachSpeicher();
        Schaf schaf= new Schaf("S1002", "Schaf", "Rasse", LocalDate.now().minusDays(3),  4, 4, 4, 4, 4, 103);
        schaf.sachSpeicher();
    }
}





