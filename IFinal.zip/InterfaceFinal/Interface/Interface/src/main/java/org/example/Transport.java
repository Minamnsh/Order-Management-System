package org.example;

public class Transport extends Sache {

    @Override
    public float getVolumen() {
        float vol = bereite * hoehe * laenge;
        return vol;
    }

    @Override
    public float getGewicht() {
        return getGewicht();
    }
}

