package org.example;

import java.util.List;

public interface IBestellungSpeichern{
    void bestellungSpeichern(Bestellung bestellung);

    List<Bestellung> ladeBestellungen();
}
