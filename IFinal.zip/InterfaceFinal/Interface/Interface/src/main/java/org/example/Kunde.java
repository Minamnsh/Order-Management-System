package org.example;

import java.io.*;
import java.time.LocalDate;

public class Kunde extends Sache {
    private String vorname;
    private String nachname;
    private String straße;
    private String hausnummer;
    private int postleitzahl;
    private String land;
    private String telefon;

    public void setkId(String kId) {
        this.kId = kId;
    }

    private String kId;
    private String fileSpeicher = "D:\\Job\\Wiberry\\Java\\InterfaceFinal\\Interface\\Interface\\target\\speicherKunde.txt";

    public String getkundeId() {
        return kId;
    }

    public String getStraße() {
        return straße;
    }

    public void setStraße(String straße) {
        this.straße = straße;
    }

    public String getHausnummer() {
        return hausnummer;
    }

    public void setHausnummer(String hausnummer) {
        this.hausnummer = hausnummer;
    }

    public int getPostleitzahl() {
        return postleitzahl;
    }

    public void setPostleitzahl(int postleitzahl) {
        this.postleitzahl = postleitzahl;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public void kundeInfo(String kundeId, String vorname, String nachname, String straße, String hausnummer,
                          int postleitzahl, String land, String telefon) {
        this.kId = kundeId;
        this.vorname = vorname;
        this.nachname = nachname;
        this.straße = straße;
        this.hausnummer = hausnummer;
        this.postleitzahl = postleitzahl;
        this.land = land;
        this.telefon = telefon;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public void kundeSpeicher() throws Exception {
        //try {
        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileSpeicher, true), "UTF-8"));
        PrintWriter out = new PrintWriter(writer);
        if (!kundeExist(getkundeId())) {
            out.println(getkundeId() + ";" + getVorname() + ";" + getNachname() + ";" + getStraße() + ";" + getHausnummer() + ";" + getPostleitzahl() + ";" + getLand() + ";" + getTelefon());
            out.close();
        } else {
            throw new Exception("Kunden mit Id " + getkundeId() + " existiert bereits!!!");
        }
            /*
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
    }

    public boolean kundeExist(String kundenId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileSpeicher))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(kundenId)) {
                    System.out.println("Kunde mit der ID '" + kundenId + "' wurde gefunden: " + line);
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

        //Datei laden
        //Datei durchsuchen nach Kunden Id
        //Kunde mit Id gefunden
        //return true;
        //Kunde mit Id nicht gefunden return false


    public void kundeLaden(String kundenId) {
        //Datei laden
        //Datei durchsuchen nach Kunden Id

        //Wenn gefunden, dann Attribute füllen
    }
}
