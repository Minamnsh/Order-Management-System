package org.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BestellungSpeichernDatei implements IBestellungSpeichern{
    private List<Bestellung> bestellungen;

    public BestellungSpeichernDatei() {
        bestellungen = new ArrayList<>();
    }

    @Override
    public void bestellungSpeichern(Bestellung bestellung) {
        bestellungen.add(bestellung);
        //System.out.println("Bestellung gespeichert für " + bestellung.getVorname() + " " + bestellung.getNachname());
    }

    @Override
    public List<Bestellung> ladeBestellungen() {
        return bestellungen;
    }

}
