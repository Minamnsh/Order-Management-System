package org.example;

import java.time.LocalDate;

public class Schaf extends Sache {

    public Schaf(String schafId, String schafName, String rasse, LocalDate geburststag, float gewicht,
                 float laenge, float bereite,
                 float hoehe, float zerbrechlich, int barcode) {
        this.setGewicht(gewicht);
        this.setSachId(schafId);
        this.setName(schafName);
        this.setHerstellDatum(geburststag);
        this.setType(rasse);
        this.setLaenge(laenge);
        this.setBereite(bereite);
        this.setHoehe(hoehe);
        this.zerbrechlich(zerbrechlich);
        this.barcode(barcode);
        this.setVolumnen();
    }
}
